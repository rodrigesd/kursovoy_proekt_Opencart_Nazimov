<?php
// HTTP
define('HTTP_SERVER', 'http://localhost/kursovoy11/admin/');
define('HTTP_CATALOG', 'http://localhost/kursovoy11/');

// HTTPS
define('HTTPS_SERVER', 'http://localhost/kursovoy11/admin/');
define('HTTPS_CATALOG', 'http://localhost/kursovoy11/');

// DIR
define('DIR_APPLICATION', 'C:/Program Files (x86)/Ampps/www/kursovoy11/admin/');
define('DIR_SYSTEM', 'C:/Program Files (x86)/Ampps/www/kursovoy11/system/');
define('DIR_IMAGE', 'C:/Program Files (x86)/Ampps/www/kursovoy11/image/');
define('DIR_LANGUAGE', 'C:/Program Files (x86)/Ampps/www/kursovoy11/admin/language/');
define('DIR_TEMPLATE', 'C:/Program Files (x86)/Ampps/www/kursovoy11/admin/view/template/');
define('DIR_CONFIG', 'C:/Program Files (x86)/Ampps/www/kursovoy11/system/config/');
define('DIR_CACHE', 'C:/Program Files (x86)/Ampps/www/kursovoy11/system/storage/cache/');
define('DIR_DOWNLOAD', 'C:/Program Files (x86)/Ampps/www/kursovoy11/system/storage/download/');
define('DIR_LOGS', 'C:/Program Files (x86)/Ampps/www/kursovoy11/system/storage/logs/');
define('DIR_MODIFICATION', 'C:/Program Files (x86)/Ampps/www/kursovoy11/system/storage/modification/');
define('DIR_UPLOAD', 'C:/Program Files (x86)/Ampps/www/kursovoy11/system/storage/upload/');
define('DIR_CATALOG', 'C:/Program Files (x86)/Ampps/www/kursovoy11/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'kursovoyroot');
define('DB_PASSWORD', '123');
define('DB_DATABASE', 'kursovoy1');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');
